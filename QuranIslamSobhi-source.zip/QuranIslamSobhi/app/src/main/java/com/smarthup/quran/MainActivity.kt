package com.smarthup.quran

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private data class Surah(val id: Int, val name: String, val url: String)

class MainActivity : AppCompatActivity() {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private lateinit var listContainer: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var nowPlaying: TextView
    private lateinit var playPause: Button
    private lateinit var progress: ProgressBar
    private var surahs: List<Surah> = emptyList()
    private var currentIndex = -1
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        buildUi()
        connectPlaybackService()
        loadSurahs()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF6F4EE.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 26, 20, 22)
            setBackgroundColor(0xFF123D32.toInt())
        }
        header.addView(TextView(this).apply {
            text = "القرآن الكريم"
            textSize = 27f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        header.addView(TextView(this).apply {
            text = "تلاوات القارئ إسلام صبحي"
            textSize = 16f
            setTextColor(0xFFE8D6A5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 0)
        })
        root.addView(header)
        statusText = TextView(this).apply {
            text = "جارٍ تحميل قائمة السور..."
            textSize = 14f
            setTextColor(0xFF34564D.toInt())
            setPadding(16, 12, 16, 8)
        }
        root.addView(statusText)
        progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress)
        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 4, 12, 12)
        }
        scroll.addView(listContainer)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val playerPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 10, 16, 12)
            setBackgroundColor(0xFFE8E4D9.toInt())
        }
        nowPlaying = TextView(this).apply {
            text = "اختر سورة للاستماع"
            textSize = 15f
            setTextColor(0xFF123D32.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        playerPanel.addView(nowPlaying)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val previous = Button(this).apply { text = "السابق"; setOnClickListener { playRelative(-1) } }
        playPause = Button(this).apply { text = "تشغيل / إيقاف"; setOnClickListener { togglePlayback() } }
        val next = Button(this).apply { text = "التالي"; setOnClickListener { playRelative(1) } }
        controls.addView(previous)
        controls.addView(playPause)
        controls.addView(next)
        playerPanel.addView(controls)
        root.addView(playerPanel)
        setContentView(root)
    }

    private fun connectPlaybackService() {
        val token = SessionToken(this, ComponentName(this, QuranPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
            } catch (_: Exception) {
                runOnUiThread { statusText.text = "تعذر تشغيل مشغل الصوت. أغلق التطبيق وافتحه مرة أخرى." }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun loadSurahs() {
        progress.visibility = View.VISIBLE
        executor.execute {
            try {
                val recitersJson = fetchJson("https://mp3quran.net/api/v3/reciters?language=ar")
                val reciters = recitersJson.getJSONArray("reciters")
                var server = ""
                var surahList = ""
                for (i in 0 until reciters.length()) {
                    val reciter = reciters.getJSONObject(i)
                    val name = reciter.optString("name")
                    if (name.contains("إسلام صبحي") || name.contains("اسلام صبحي") || name.contains("Islam Sobhi", true)) {
                        val moshaf = reciter.optJSONArray("moshaf") ?: continue
                        if (moshaf.length() > 0) {
                            val edition = moshaf.getJSONObject(0)
                            server = edition.optString("server")
                            surahList = edition.optString("surah_list")
                            break
                        }
                    }
                }
                if (server.isBlank() || surahList.isBlank()) throw IllegalStateException("لم يتم العثور على مصدر تلاوات إسلام صبحي في الدليل الصوتي.")
                val allowed = surahList.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
                val surahJson = fetchJson("https://mp3quran.net/api/v3/suwar?language=ar")
                val names = surahJson.getJSONArray("suwar")
                val result = ArrayList<Surah>()
                for (i in 0 until names.length()) {
                    val item = names.getJSONObject(i)
                    val id = item.optInt("id")
                    if (id in allowed) {
                        val filename = String.format(Locale.US, "%03d.mp3", id)
                        result.add(Surah(id, item.optString("name"), server.trimEnd('/') + "/" + filename))
                    }
                }
                runOnUiThread {
                    progress.visibility = View.GONE
                    surahs = result
                    if (surahs.isEmpty()) {
                        statusText.text = "لم تصل قائمة السور من المصدر. تحقق من الإنترنت وحاول مجددًا."
                    } else {
                        statusText.text = "${surahs.size} سورة متاحة • يحتاج التشغيل إلى الإنترنت"
                        renderSurahs()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    statusText.text = "تعذر تحميل السور. تحقق من اتصال الإنترنت ثم أعد فتح التطبيق."
                    Toast.makeText(this, e.message ?: "خطأ غير معروف", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun fetchJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
            return JSONObject(connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }

    private fun renderSurahs() {
        listContainer.removeAllViews()
        surahs.forEachIndexed { index, surah ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(if (index % 2 == 0) 0xFFFFFFFF.toInt() else 0xFFF0EEE6.toInt())
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val title = TextView(this).apply {
                text = "${surah.id}. ${surah.name}"
                textSize = 17f
                setTextColor(0xFF173F34.toInt())
                typeface = Typeface.DEFAULT_BOLD
            }
            row.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            val button = Button(this).apply {
                text = "استمع"
                setOnClickListener { playSurah(index) }
            }
            row.addView(button)
            row.setOnClickListener { playSurah(index) }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = 5
            listContainer.addView(row, params)
        }
    }

    private fun playSurah(index: Int) {
        if (index !in surahs.indices) return
        val player = controller
        if (player == null) {
            Toast.makeText(this, "مشغل الصوت ما زال يجهز، حاول مرة أخرى بعد لحظة", Toast.LENGTH_SHORT).show()
            return
        }
        currentIndex = index
        val surah = surahs[index]
        val item = MediaItem.Builder()
            .setUri(surah.url)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(surah.name).setArtist("إسلام صبحي").build())
            .build()
        player.setMediaItem(item)
        player.prepare()
        player.play()
        nowPlaying.text = "يُشغّل الآن: ${surah.name} — إسلام صبحي"
        playPause.text = "إيقاف مؤقت"
    }

    private fun togglePlayback() {
        val player = controller ?: return
        if (player.isPlaying) {
            player.pause()
            playPause.text = "استكمال"
        } else if (player.mediaItemCount > 0) {
            player.play()
            playPause.text = "إيقاف مؤقت"
        } else if (surahs.isNotEmpty()) {
            playSurah(0)
        }
    }

    private fun playRelative(delta: Int) {
        if (surahs.isEmpty()) return
        val nextIndex = if (currentIndex < 0) 0 else (currentIndex + delta + surahs.size) % surahs.size
        playSurah(nextIndex)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        executor.shutdownNow()
        super.onDestroy()
    }
}
